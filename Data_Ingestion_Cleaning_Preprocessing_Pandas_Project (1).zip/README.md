# Data Ingestion, Cleaning & Preprocessing with Pandas

Files:
- `messy_retail_sales.csv` — raw 12,100-row dataset containing quality issues.
- `clean_retail_sales.csv` — cleaned and feature-engineered dataset.
- `Data_Ingestion_Cleaning_Preprocessing_Pandas.ipynb` — Jupyter Notebook showing the complete workflow.

Key cleaning operations:
- Missing-value handling
- Duplicate removal
- Date and numeric type conversion
- Text standardization
- Invalid quantity/price handling
- Profit and profit-margin feature engineering
- Year/month/quarter extraction
